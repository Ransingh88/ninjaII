console.log(typeof 1729) //number
console.log(typeof "Masai School") //String
console.log(typeof false) //boolean
console.log(typeof "") //string
console.log(typeof undefined) //undefined