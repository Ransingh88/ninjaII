var firstName = "Debasish";
var lastName = "Ransingh";
var age = 24;
var address = "123L Bhubaneswar";
var city = "Bhubaneswar";
var state = "Odisha";
var pincode = 752030;

console.log("My name is " + firstName + " " + lastName);
console.log("My age is " + age);
console.log("My address is " + address);
console.log("I live in city " + city + " which is in " + state);
console.log("My area pincode is " + pincode);