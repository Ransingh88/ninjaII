var length = 17;
var breadth = 10;

var perimeter = 2 * (length + breadth);
var area = length * breadth;

console.log(perimeter);
console.log(area);