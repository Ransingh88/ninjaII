var mark1 = 73;
var mark2 = 85;
var mark3 = 62;
var full_mark = 100;
var total_subject = 3;

var percentage = ((mark1 + mark2 + mark3) / (full_mark * total_subject)) * 100;

console.log(percentage);