var a = 3;
var b = 2;

var addition = a + b;
var subtraction = a - b;
var multiplication = a * b;
var division = a / b;
var modulous = a % b;
var increament = a++;
var decreament = b--;
var result = (a ** b) - (b ** a);

console.log(addition);
console.log(subtraction);
console.log(multiplication);
console.log(division);
console.log(modulous);
console.log(increament);
console.log(decreament);
console.log(result);