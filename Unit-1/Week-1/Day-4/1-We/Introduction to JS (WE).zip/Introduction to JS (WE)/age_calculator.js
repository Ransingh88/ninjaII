var birth_year = 1998;
var current_year = 2021;
var age  = current_year - birth_year;
console.log(age);