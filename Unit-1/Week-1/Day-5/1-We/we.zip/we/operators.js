var a = 10;

a +=2; //this is add and assignment
a -=3;//this is substract and assignment
a /=6;//this is devide and assignment
a *=11;//this is multiply and assignment
a %=7;//this is modulos and assignment

console.log(a);