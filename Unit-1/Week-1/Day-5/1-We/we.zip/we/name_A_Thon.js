var averageAge = 26;
var numberOfStudents = 150;
var maximunMarks = 100;
var theFirstName = "Debasish Ransingh";
var numberOfStudentIn12thClass = 54;