/* Simple Interest
Formula
SimpleIntrest = (Principle * Rate * Time) / 100
*/

var principle = 100000; //this is principle ammount
var rate = 8; //this is the annual rate
var time = 5; //this is the time in year

var simpleInterest = (principle * rate * time) / 100;
console.log(simpleInterest);