var address = {
    houseNumber: "123B",
    area: "abc",
    city: "xyz",
    state: "odisha",
    pincode: 751002,
    mobileNumber: 785968457,
    greeting: function () {
        console.log("Hello World");
    },
};

console.log(address)