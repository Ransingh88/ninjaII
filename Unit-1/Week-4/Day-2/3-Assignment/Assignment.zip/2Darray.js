function runProgram(input) {
  var newInput = input.split(/[\r\n]+/);
  var arr = newInput.slice(0,).map(function (row) {
    return row.split(" ").map(Number);
  })
    row = newInput.length;
    col =arr[0].length;

    for (var i = 0; i < row; i++){
        res = ""
        for (var j = 0; j < col; j++){
            res+=arr[i][j] + " "
        }
        console.log(res)
    }
//console.log(row,col,arr)
}




input =
`1 2 3 4
5 6 7 6
7 8 9 9
2 4 1 3`
runProgram(input);