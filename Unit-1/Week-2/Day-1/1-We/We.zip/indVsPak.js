var finalScoreInd = 324;
var finalScorePak = 323;

if (finalScoreInd > finalScorePak){
    console.log("India Wins");
} else if (finalScorePak > finalScoreInd){
    console.log("Pakistan Wins");
} else {
    console.log("Match Tied");
}