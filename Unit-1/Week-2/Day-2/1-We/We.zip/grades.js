var grade = "A";

switch (grade) {
    case "A":
        console.log("Excellent");
        break;
    case "B":
        console.log("Very Good");
        break;
    case "C":
        console.log("Good");
        break;
    case "D":
        console.log("Needs a ot of Improvement");
        break;
    case "F":
        console.log("Failed");
        break;
}