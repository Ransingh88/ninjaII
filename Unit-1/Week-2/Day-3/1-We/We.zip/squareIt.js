// for (var i = 1; i <= 10; i++){
//     console.log("The square of ", i, " is ", i*i)
// }


// for (var i = 1; i <= 10; i++){
//     console.log(`The square of ${i} is ${i * i}`)
// }

var a = 1;
while (a <= 10) {
    console.log(`The Square of ${a} is ${a * a}`);
    a++;
}