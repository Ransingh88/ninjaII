// for (var i = 50; i <= 150; i++){
//     if (i % 7 == 0) {
//         console.log(i);
//     }
// }

var i = 50;

while (i <= 150) {
    if (i % 7 == 0) {
        console.log(i);
    }
    i++
}