var result = 1;
var n = 4;
for (var i = 1; i <= n; i++){
    result = result * i;
}
console.log(result);